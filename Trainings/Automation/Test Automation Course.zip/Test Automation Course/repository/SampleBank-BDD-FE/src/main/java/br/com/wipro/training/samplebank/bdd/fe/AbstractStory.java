package br.com.wipro.training.samplebank.bdd.fe;

import static org.jbehave.core.reporters.Format.TXT;
import static org.jbehave.core.reporters.Format.XML;

import java.text.SimpleDateFormat;
import java.util.Properties;

import org.jbehave.core.Embeddable;
import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.embedder.StoryControls;
import org.jbehave.core.i18n.LocalizedKeywords;
import org.jbehave.core.io.CodeLocations;
import org.jbehave.core.io.LoadFromClasspath;
import org.jbehave.core.io.UnderscoredCamelCaseResolver;
import org.jbehave.core.junit.JUnitStory;
import org.jbehave.core.model.ExamplesTableFactory;
import org.jbehave.core.parsers.RegexStoryParser;
import org.jbehave.core.reporters.FilePrintStreamFactory.ResolveToPackagedName;
import org.jbehave.core.reporters.Format;
import org.jbehave.core.reporters.StoryReporterBuilder;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.ParameterConverters;
import org.jbehave.core.steps.ParameterConverters.DateConverter;
import org.jbehave.core.steps.ParameterConverters.ExamplesTableConverter;
import org.jbehave.core.steps.spring.SpringApplicationContextFactory;
import org.jbehave.core.steps.spring.SpringStepsFactory;
import org.jbehave.web.selenium.SeleniumConfiguration;
import org.jbehave.web.selenium.WebDriverProvider;
import org.springframework.context.ApplicationContext;

import br.com.wipro.training.samplebank.bdd.fe.report.ScreenshootingHtmlFormat;

public abstract class AbstractStory extends JUnitStory {

	private static final String APP_CONTEXT_LOCATION = "classpath:configs/application-context.xml"; 
	
	private ApplicationContext appContext;
	
	public AbstractStory() {
		
		appContext = new SpringApplicationContextFactory(APP_CONTEXT_LOCATION).createApplicationContext();
		
		configuredEmbedder().embedderControls()
				.doGenerateViewAfterStories(true)
				.doIgnoreFailureInStories(true).doIgnoreFailureInView(true)
				.useThreads(1).useStoryTimeoutInSecs(600L);
	}

	@Override
	public Configuration configuration() {
		
		Class<? extends Embeddable> embeddableClass = this.getClass();
		
		Properties viewResources = new Properties();
		viewResources.put("decorateNonHtml", "true");
		
		// Start from default ParameterConverters instance
		ParameterConverters parameterConverters = new ParameterConverters();
		
		// factory to allow parameter conversion and loading from external
		// resources (used by StoryParser too)
		ExamplesTableFactory examplesTableFactory = new ExamplesTableFactory(
				new LocalizedKeywords(),
				new LoadFromClasspath(embeddableClass), parameterConverters);
		
		// add custom converters
		parameterConverters.addConverters(new DateConverter(
				new SimpleDateFormat("yyyy-MM-dd")),
				new ExamplesTableConverter(examplesTableFactory));
		
		// Selenium Web Driver Provider from Spring context
		WebDriverProvider webDriverProvider = appContext.getBean(WebDriverProvider.class);
		
		// Custom Selenium screenshot report format
		Format screenshootingFormat = new ScreenshootingHtmlFormat(webDriverProvider);
		
		return new SeleniumConfiguration()
				.useWebDriverProvider(webDriverProvider)
				.useStoryControls(
						new StoryControls().doDryRun(false)
								.doSkipScenariosAfterFailure(false))
				.useStoryLoader(new LoadFromClasspath(embeddableClass))
				.useStoryParser(new RegexStoryParser(examplesTableFactory))
				.useStoryPathResolver(new UnderscoredCamelCaseResolver())
				.useStoryReporterBuilder(
						new StoryReporterBuilder()
								.withCodeLocation(
										CodeLocations
												.codeLocationFromClass(embeddableClass))
								.withDefaultFormats()
								.withPathResolver(new ResolveToPackagedName())
								.withViewResources(viewResources)
								.withFormats(screenshootingFormat, TXT, XML)
								.withFailureTrace(true)
								.withFailureTraceCompression(true))
				.useParameterConverters(parameterConverters);
	}

	@Override
	public InjectableStepsFactory stepsFactory() {
		return new SpringStepsFactory(configuration(), appContext);
	}
}