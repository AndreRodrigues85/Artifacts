package br.com.wipro.training.samplebank.bdd.fe.browsers;

import javax.annotation.PostConstruct;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.wipro.training.samplebank.bdd.fe.proxy.ProxyManager;

public class CustomFirefoxCapabilities extends DesiredCapabilities {

	private static final long serialVersionUID = 1L;

	@Autowired
	private ProxyManager proxyManager;
	
	@PostConstruct
	public void initializeCapabilities() {
		setCapability(CapabilityType.PROXY, proxyManager.getSeleniumProxy());
	}
}