package br.com.wipro.training.samplebank.bdd.fe.browsers;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;
import org.openqa.selenium.firefox.FirefoxProfile;

public class CustomFirefoxProfile extends FirefoxProfile {

	private static final String MIME_TYPE_TEXT_CSV = "text/csv";
    private static final String MIME_TYPE_EXCEL_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    
    private static final String DOWNLOAD_PATH_WIN = "C:\\Selenium\\Downloads\\";
    private static final String DOWNLOAD_PATH_LINUX = "/temp/";
        
	public CustomFirefoxProfile() {
		
		setAcceptUntrustedCertificates(true);
		
		/*
		 * Download Management
		 * Folder List: 0 - Desktop, 1 - System Default Download, 2 - Custom Folder
		 */
        setPreference("browser.download.folderList", 2);
        setPreference("browser.helperApps.neverAsk.saveToDisk", 
        		StringUtils.join(new Object[]{MIME_TYPE_TEXT_CSV,MIME_TYPE_EXCEL_XLSX}, ","));
        setPreference("browser.download.dir", getDownloadFolderPath());
        setPreference("browser.download.manager.showAlertOnComplete", false);
        
        /*
         * Proxies
         */
        //setPreference("network.proxy.no_proxies_on", "localhost, 127.0.0.1");
	}
	
	private String getDownloadFolderPath() {
		if(SystemUtils.IS_OS_WINDOWS) {
			return DOWNLOAD_PATH_WIN;
		} else if(SystemUtils.IS_OS_LINUX) {
			return DOWNLOAD_PATH_LINUX;
		}		
		return null;
	}
}