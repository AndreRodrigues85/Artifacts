package br.com.wipro.training.samplebank.bdd.fe.context;

import org.springframework.stereotype.Component;

@Component
public class FrontEndTestExecutionContext {

	
}