package br.com.wipro.training.samplebank.bdd.fe.driver;

import org.jbehave.web.selenium.DefaultWebDriverProvider;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeWebDriverProvider extends DefaultWebDriverProvider {
	
	private ChromeDriver chromeDriver;

	@Override
	public WebDriver get() {
		initialize();
		return chromeDriver;
	}
	
	@Override
	public void initialize() {
		if(chromeDriver == null){
			System.setProperty("webdriver.chrome.driver", "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe");
			chromeDriver = new ChromeDriver();
		}
	}
	
	@Override
	public void end() {
		chromeDriver.quit();
	}
}