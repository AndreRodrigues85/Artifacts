package br.com.wipro.training.samplebank.bdd.fe.driver;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.jbehave.web.selenium.FirefoxWebDriverProvider;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import br.com.wipro.training.samplebank.bdd.fe.browsers.CustomFirefoxCapabilities;
import br.com.wipro.training.samplebank.bdd.fe.browsers.CustomFirefoxProfile;


public class CustomWebDriverProvider extends FirefoxWebDriverProvider {

	/*
	 * The actual model that JBehave use to create the web driver is using a ThreadLocal, 
	 * what causes some troubles since JBehave can run in a multi thread environment. 
	 * Then, we have to control the created web driver to avoid this kind of issue, that 
	 * usually appears as a Web Driver not found exception.
	 */
	private final Map<String, WebDriver> safeWebDriverHolder = new ConcurrentHashMap<>();
	
	@Override
	public void initialize() {

		FirefoxBinary binary = new FirefoxBinary();
		decorateFirefoxBinary(binary);

		FirefoxProfile profile = new CustomFirefoxProfile();

		Capabilities capabilities = new CustomFirefoxCapabilities();

		WebDriver webDriver =  new CustomFirefoxDriver(binary, profile, capabilities);
		
		safeWebDriverHolder.put("webDriver", webDriver);
	}

	@Override
	public WebDriver get() {
		WebDriver webDriver = safeWebDriverHolder.get("webDriver");
        if (webDriver == null) {
            throw new DelegateWebDriverNotFound();
        }
        return webDriver;
	}
	
	@Override
	public void end() {	
		safeWebDriverHolder.get("webDriver").quit();
		safeWebDriverHolder.remove("webDriver");
    }

	
	/*
	 * Overrided Firefox Driver
	 */
	private class CustomFirefoxDriver extends FirefoxDriver {

		public CustomFirefoxDriver(FirefoxBinary binary,
				FirefoxProfile profile, Capabilities capabilities) {
			super(binary, profile, capabilities);
		}
	}
}