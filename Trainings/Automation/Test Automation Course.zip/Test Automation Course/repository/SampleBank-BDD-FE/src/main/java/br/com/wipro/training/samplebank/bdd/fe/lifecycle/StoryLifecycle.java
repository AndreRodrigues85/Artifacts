package br.com.wipro.training.samplebank.bdd.fe.lifecycle;

import java.awt.AWTException;
import java.awt.Robot;

import org.jbehave.core.annotations.AfterStories;
import org.jbehave.core.annotations.BeforeStories;
import org.jbehave.web.selenium.WebDriverProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import br.com.wipro.training.samplebank.bdd.fe.context.FrontEndTestExecutionContext;
import br.com.wipro.training.samplebank.bdd.fe.proxy.ProxyManager;

@Component
public class StoryLifecycle {

	@Autowired
	private WebDriverProvider webDriverProvider;
	
	@Autowired
	private FrontEndTestExecutionContext context;
	
	@Autowired
	private ProxyManager proxyManager;
	
	@Value("${sbservices.watch.network:false}")
	private boolean watchNetwork;

	@BeforeStories
	public void setupStories() {
		
		webDriverProvider.initialize();
		webDriverProvider.get().manage().window().maximize();
		
		if(watchNetwork) {
			proxyManager.startProxyServer();
		}
		
		resetMousePosition();
	}
	
	@AfterStories
	public void tearDownStories() {
		proxyManager.getFailedBrowserNetworkEntries();
		proxyManager.stopProxySever();
		
		webDriverProvider.get().manage().deleteAllCookies();
		webDriverProvider.end();
	}
	
	private void resetMousePosition() {
		try {
			Robot robot = new Robot();
			robot.mouseMove(0, 0);
		} catch (AWTException e) {
			e.printStackTrace();
		}
	}
}