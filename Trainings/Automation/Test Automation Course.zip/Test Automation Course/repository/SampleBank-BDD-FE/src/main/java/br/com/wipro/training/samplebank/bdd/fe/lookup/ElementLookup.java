package br.com.wipro.training.samplebank.bdd.fe.lookup;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.jbehave.web.selenium.WebDriverProvider;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ElementLookup {

	@Autowired
	private WebDriverProvider webDriverProvider;

	public SBElement searchById(String id) {
		try {
			WebElement e = webDriverProvider.get().findElement(By.id(id));
			if (e != null) {
				return new SBElement(e, this);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}

	public SBElement searchById(SBElement parent, String id) {
		try {

			WebElement e = parent.getWebElement().findElement(By.id(id));
			if (e != null) {
				return new SBElement(e, this);
			}
		} catch (Exception e) {
			return null;
		}

		return null;
	}

	public SBElement searchByName(String name) {
		try {

			if (!"".equals(name)) {
				WebElement e = webDriverProvider.get().findElement(
						By.name(name));
				return new SBElement(e, this);
			}
		} catch (Exception e) {
			return null;
		}
		return null;
	}

	public SBElement searchByName(SBElement sbElement, String string) {
		try {
			WebElement e = sbElement.getWebElement().findElement(
					By.name(string));
			return new SBElement(e, this);
		} catch (Exception e) {
			return null;
		}
	}

	public SBElement searchByClassName(SBElement sbElement, String className) {
		try {

			if (!"".equals(className)) {
				WebElement e = sbElement.getWebElement().findElement(
						By.cssSelector(concatClasses(className)));
				if (e != null) {
					return new SBElement(e, this);
				}
			}
		} catch (Exception e) {
			return null;
		}
		return null;
	}

	public SBElement searchByClassName(String className) {
		List<SBElement> sbElements = findByClassName(className);
		if (sbElements != null) {
			return sbElements.get(0);
		}

		return null;
	}

	public List<SBElement> findByClassName(String className) {
		try {

			List<SBElement> sbElements = new ArrayList<SBElement>();

			if (!"".equals(className)) {
				List<WebElement> elements = webDriverProvider.get()
						.findElements(By.cssSelector(concatClasses(className)));
				if (elements != null && !elements.isEmpty()) {
					for (WebElement webElement : elements) {
						sbElements.add(new SBElement(webElement, this));
					}
					return sbElements;
				}
			}
		} catch (Exception e) {
			return null;
		}
		return null;
	}

	WebDriver getWebDriver() {
		return webDriverProvider.get();
	}

	private String concatClasses(String classNames) {
		String[] classes = classNames.split(" ");
		String ret = StringUtils.join(classes, ".");
		return ".".concat(ret);
	}
}