package br.com.wipro.training.samplebank.bdd.fe.lookup;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class SBElement {

	private ElementLookup elementLookup;
	private WebElement webElement;
	private String id;
	private String textValue;

	SBElement(WebElement e, ElementLookup lookup) {
		this.webElement = e;
		try {
			this.elementLookup = lookup;
			this.id = e.getAttribute("id");
			e.getAttribute("type");
			this.textValue = webElement.getAttribute("textContent");
		} catch (StaleElementReferenceException e2) {
			throw new RuntimeException();
		}
	}

	WebElement getWebElement() {
		return webElement;
	}

	public void doubleClick() {
		new Actions(elementLookup.getWebDriver()).doubleClick();
	}

	public void click() {
		try {
			webElement.click();
		} catch (StaleElementReferenceException e) {
			elementLookup.searchById(this.id);
			click();
		}

	}

	public void sendKeys(String value) {
		webElement.sendKeys(value);
	}

	public String getInnerText() {
		return this.textValue;
	}

	public String getText() {
		return webElement.getText();
	}

	public String getHref() {
		return webElement.getAttribute("href");
	}

	public boolean isVisible() {
		return webElement.isDisplayed();
	}

	public boolean isLoaded() {
		return webElement != null;
	}
}