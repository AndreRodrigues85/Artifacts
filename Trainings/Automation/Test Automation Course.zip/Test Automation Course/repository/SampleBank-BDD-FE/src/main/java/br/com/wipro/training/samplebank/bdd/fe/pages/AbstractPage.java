package br.com.wipro.training.samplebank.bdd.fe.pages;

import org.springframework.beans.factory.annotation.Autowired;

import br.com.wipro.training.samplebank.bdd.fe.lookup.ElementLookup;
import br.com.wipro.training.samplebank.bdd.fe.lookup.SBElement;
import br.com.wipro.training.samplebank.bdd.fe.util.JavaScriptExecutorHelper;
import br.com.wipro.training.samplebank.bdd.fe.util.NavigatorHelper;

public abstract class AbstractPage {

	@Autowired
	private ElementLookup elementLookup;
	
	@Autowired
	private NavigatorHelper navigator;
	
	@Autowired
	private JavaScriptExecutorHelper jsexecutor;
	
	public boolean isLoaded(){
		return get().isLoaded();
	}
	
	public boolean isVisible(){
		return get().isVisible();
	}
	
	public abstract SBElement get();
	
	protected JavaScriptExecutorHelper getJsexecutor() {
		return jsexecutor;
	}
	
	protected NavigatorHelper getNavigator() {
		return navigator;
	}
	
	protected void fillInputByName(String inputName, String value){
		SBElement element = elementLookup.searchByName(inputName);
		if(element != null){
			element.sendKeys(value);
		}else{
			throw new RuntimeException("Element not found");
		}
		
		
	}
	
	protected void fillInput(SBElement element, String value){
		//validate if element is a input
		if(element != null){
			element.sendKeys(value);
		}else{
			throw new RuntimeException("Element not found");
		}
	}
	
	protected void clickElement(SBElement element){
		if(element != null){
			element.click();
		}else{
			throw new RuntimeException("Element not found");
		}
	}
	
	protected ElementLookup getElementLookup() {
		return elementLookup;
	}
}
