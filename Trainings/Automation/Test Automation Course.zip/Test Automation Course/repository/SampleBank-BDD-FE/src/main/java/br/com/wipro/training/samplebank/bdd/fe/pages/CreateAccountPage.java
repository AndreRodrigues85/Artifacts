package br.com.wipro.training.samplebank.bdd.fe.pages;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import br.com.wipro.training.samplebank.bdd.fe.lookup.SBElement;
import br.com.wipro.training.samplebank.bdd.fe.pages.components.CreateAccountForm;

@Component
public class CreateAccountPage extends AbstractPage {

	private CreateAccountForm createAccountForm;

	@PostConstruct
	public void initialize() {
		createAccountForm = new CreateAccountForm(this, getElementLookup());
	}

	@Override
	public SBElement get() {
		return getElementLookup().searchById("createAccountPage");
	}

	public CreateAccountForm getForm() {
		return createAccountForm;
	}

}
