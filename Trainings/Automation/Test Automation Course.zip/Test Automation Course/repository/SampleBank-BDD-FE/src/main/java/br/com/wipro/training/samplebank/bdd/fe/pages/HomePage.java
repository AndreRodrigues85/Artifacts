package br.com.wipro.training.samplebank.bdd.fe.pages;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import br.com.wipro.training.samplebank.bdd.fe.lookup.SBElement;
import br.com.wipro.training.samplebank.bdd.fe.pages.components.AdminMenu;

@Component
public class HomePage extends AbstractPage {

	private AdminMenu adminMenu;
	
	@PostConstruct
	public void initialize(){
		adminMenu = new AdminMenu(this, getElementLookup());
	}
	
	public AdminMenu getAdminMenu() {
		return adminMenu;
	}
	
	public boolean isLoaded() {
		return getElementLookup().searchByClassName("sb-home-container") != null;
	}
	
	public SBElement getLoginInfo(){
		return getElementLookup().searchByClassName("sb-login-info");
	}
	
	public SBElement getUsernameTextField(){
		return getElementLookup().searchById(getLoginInfo(), "sb-username");
	}
	
	public String getUsernameValue(){
		
		Pattern pattern = Pattern.compile(",\\s*([\\w]+)\\s*\\(");
		
		Matcher matcher = pattern.matcher(getUsernameTextField().getInnerText());
		
		String actualUsername = "";
		
		if(matcher.find()) {
			actualUsername = matcher.group(1);
		}
		
		return actualUsername;
	}

	@Override
	public SBElement get() {
		return getElementLookup().searchByClassName("sb-home-container");
	}

}
