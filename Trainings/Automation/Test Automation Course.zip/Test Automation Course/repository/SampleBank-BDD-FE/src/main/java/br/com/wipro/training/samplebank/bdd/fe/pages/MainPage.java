package br.com.wipro.training.samplebank.bdd.fe.pages;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import br.com.wipro.training.samplebank.bdd.fe.lookup.ElementLookup;
import br.com.wipro.training.samplebank.bdd.fe.lookup.SBElement;
import br.com.wipro.training.samplebank.bdd.fe.pages.components.LoginForm;

@Component
public class MainPage extends AbstractPage{

	@Value("${sbservices.url.index}")
	private String indexPageUrl;
	
	private LoginForm loginForm;
	
	@Autowired
	private ElementLookup lookup;
	
	public MainPage() {
	}
	
	@PostConstruct
	public void initialize(){
		loginForm = new LoginForm(this, lookup);
	}

	
	public void goToMainPage(){
		getNavigator().navigateTo(indexPageUrl);
	}


	@Override
	public SBElement get() {
		return lookup.searchByClassName("sb-index-container");
	}
	
	public LoginForm getLoginForm() {
		return loginForm;
	}

}
