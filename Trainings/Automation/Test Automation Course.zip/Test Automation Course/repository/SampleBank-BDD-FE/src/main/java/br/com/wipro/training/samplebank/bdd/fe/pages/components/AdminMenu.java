package br.com.wipro.training.samplebank.bdd.fe.pages.components;

import java.util.List;

import br.com.wipro.training.samplebank.bdd.fe.lookup.ElementLookup;
import br.com.wipro.training.samplebank.bdd.fe.lookup.SBElement;
import br.com.wipro.training.samplebank.bdd.fe.pages.HomePage;

public class AdminMenu {

	private ElementLookup lookup;
	
	public AdminMenu(HomePage homePage, ElementLookup lookup ) {
		this.lookup = lookup;
	}
	
	public SBElement getAddAccountLink(){
		String link = "addAccount";
		List<SBElement> links = lookup.findByClassName("linkButton");
		for (SBElement sbElement : links) {
			if(sbElement.getHref().endsWith(link)){
				return sbElement;
			}
		}
		return null;
	}
}