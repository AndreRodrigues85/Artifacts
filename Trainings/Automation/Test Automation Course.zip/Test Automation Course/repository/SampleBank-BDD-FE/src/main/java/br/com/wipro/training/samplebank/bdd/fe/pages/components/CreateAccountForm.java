package br.com.wipro.training.samplebank.bdd.fe.pages.components;

import br.com.wipro.training.samplebank.bdd.fe.lookup.ElementLookup;
import br.com.wipro.training.samplebank.bdd.fe.lookup.SBElement;
import br.com.wipro.training.samplebank.bdd.fe.pages.AbstractPage;

public class CreateAccountForm {
	
	private AbstractPage parentPage;
	private ElementLookup lookup;

	public CreateAccountForm(AbstractPage parentPage, ElementLookup lookup) {
		// TODO Auto-generated constructor stub
		this.parentPage = parentPage;
		this.lookup = lookup;  
	}
	
	public SBElement getCPFInput(){
		return lookup.searchByClassName(parentPage.get(),"addAcount ownerCpf");
	}
	
	public SBElement getMessageField(){
		return lookup.searchById(parentPage.get(), "sb-return-message");
	}
	
	public SBElement getRegisterAccountButton(){
		return lookup.searchById("sb-btn-login");
		
	}
	
	public void setCpfInputValue(String value){
		getCPFInput().sendKeys(value);
	}
}
