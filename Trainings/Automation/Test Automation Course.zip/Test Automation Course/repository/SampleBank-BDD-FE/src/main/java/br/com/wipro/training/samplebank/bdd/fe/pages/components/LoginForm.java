package br.com.wipro.training.samplebank.bdd.fe.pages.components;

import br.com.wipro.training.samplebank.bdd.fe.lookup.ElementLookup;
import br.com.wipro.training.samplebank.bdd.fe.lookup.SBElement;
import br.com.wipro.training.samplebank.bdd.fe.pages.AbstractPage;

public class LoginForm {

	//private SBElement inputLogin;
	//private SBElement inputPassword;
	private AbstractPage parent;
	private ElementLookup lookup;
	
	public LoginForm(AbstractPage parent, ElementLookup lookup) {
		// TODO Auto-generated constructor stub
		this.parent = parent;
		this.lookup = lookup;
	}
	
	public SBElement getInputUsername(){
		return lookup.searchByName(parent.get(), "username");
	}
	
	public SBElement getInputPassword() {
		return lookup.searchByName(parent.get(),"password");
	}
	
	public SBElement getLoginButton() {
		return lookup.searchById(parent.get(),"sb-btn-login");
	}

	public void fillUsernameInput(String username) {
		getInputUsername().sendKeys(username);
		
	}

	public void fillPasswordInput(String password) {
		getInputPassword().sendKeys(password);
		
	}

	public void clickOnLoginButton() {
		getLoginButton().click();
	}

}
