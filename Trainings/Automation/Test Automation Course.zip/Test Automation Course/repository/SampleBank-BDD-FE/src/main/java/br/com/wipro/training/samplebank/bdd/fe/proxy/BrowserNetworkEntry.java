package br.com.wipro.training.samplebank.bdd.fe.proxy;

import java.util.Date;

import net.lightbody.bmp.core.har.HarPostData;

public class BrowserNetworkEntry {

	private Date startedDateTime;
	private long duration;
	private String requestMethod;
	private HarPostData requestPostData;
	private String requestAddress;
	private int httpResponseCode;
	private String httpResponseText;

	public Date getStartedDateTime() {
		return startedDateTime;
	}

	public void setStartedDateTime(Date startedDateTime) {
		this.startedDateTime = startedDateTime;
	}

	public long getDuration() {
		return duration;
	}

	public void setDuration(long duration) {
		this.duration = duration;
	}

	public String getRequestMethod() {
		return requestMethod;
	}

	public void setRequestMethod(String requestMethod) {
		this.requestMethod = requestMethod;
	}

	public HarPostData getRequestPostData() {
		return requestPostData;
	}

	public void setRequestPostData(HarPostData requestPostData) {
		this.requestPostData = requestPostData;
	}

	public String getRequestAddress() {
		return requestAddress;
	}

	public void setRequestAddress(String requestAddress) {
		this.requestAddress = requestAddress;
	}

	public int getHttpResponseCode() {
		return httpResponseCode;
	}

	public void setHttpResponseCode(int httpResponseCode) {
		this.httpResponseCode = httpResponseCode;
	}

	public String getHttpResponseText() {
		return httpResponseText;
	}

	public void setHttpResponseText(String httpResponseText) {
		this.httpResponseText = httpResponseText;
	}

}