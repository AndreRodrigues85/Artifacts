package br.com.wipro.training.samplebank.bdd.fe.proxy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.lightbody.bmp.core.har.Har;
import net.lightbody.bmp.core.har.HarEntry;
import net.lightbody.bmp.proxy.ProxyServer;

import org.openqa.selenium.Proxy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ProxyManager {
	
	private static final int PORT = 9999;

	@Value("${sbservices.url.index}")
	private String baseUrl;
	
	@Value("${sbservices.proxy.real:false}")
	private boolean useRealProxy;
	
	@Value("${sbservices.proxy.address}")
	private String realProxyAddress;

	private String domain;

	private ProxyServer proxyServer;

	private boolean started;

	public void startProxyServer() {
		try {

			Map<String, String> options = new HashMap<String, String>();
			
			proxyServer = new ProxyServer(PORT);
			proxyServer.start();
			
			proxyServer.setCaptureHeaders(true);
			proxyServer.setCaptureContent(true);

			if (useRealProxy) {
				options.put("httpProxy", realProxyAddress);
			}

			proxyServer.setOptions(options);
			proxyServer.newHar("localhost");

			started = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void stopProxySever() {
		try {
			proxyServer.stop();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Proxy getSeleniumProxy() {
		
		Proxy seleniumProxy = proxyServer.seleniumProxy();

		seleniumProxy.setHttpProxy("localhost:".concat(String.valueOf(PORT)));
		seleniumProxy.setFtpProxy("localhost:".concat(String.valueOf(PORT)));
		seleniumProxy.setSslProxy("localhost:".concat(String.valueOf(PORT)));
		seleniumProxy.setNoProxy("");
		
		return seleniumProxy;
	}

	public Har getHistory() {
		Har history = proxyServer.getHar();
		return history;
	}

	public void clearHistory() {
		proxyServer.newHar(domain);
	}

	public List<BrowserNetworkEntry> getFailedBrowserNetworkEntries() {

		/*
		 * HTTP Error code from 400 to 599 range are error codes
		 */
		List<BrowserNetworkEntry> ret = new ArrayList<BrowserNetworkEntry>();

		for (HarEntry entry : getHistory().getLog().getEntries()) {

			int httpCode = entry.getResponse().getStatus();

			if (httpCode >= 400 && httpCode < 600) {

				BrowserNetworkEntry bne = new BrowserNetworkEntry();

				bne.setStartedDateTime(entry.getStartedDateTime());
				bne.setDuration(entry.getTime());
				bne.setRequestMethod(entry.getRequest().getMethod());
				bne.setRequestPostData(entry.getRequest().getPostData());
				bne.setRequestAddress(entry.getRequest().getUrl());
				bne.setHttpResponseCode(httpCode);
				bne.setHttpResponseText(entry.getResponse().getStatusText());

				ret.add(bne);
			}
		}
		return ret;
	}

	public boolean isStarted() {
		return started;
	}
}