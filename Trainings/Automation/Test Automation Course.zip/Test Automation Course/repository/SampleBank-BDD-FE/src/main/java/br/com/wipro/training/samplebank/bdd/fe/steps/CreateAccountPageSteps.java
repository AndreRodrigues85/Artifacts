package br.com.wipro.training.samplebank.bdd.fe.steps;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.wipro.training.samplebank.bdd.fe.pages.CreateAccountPage;

@Component
public class CreateAccountPageSteps {

	@Autowired
	private CreateAccountPage page;
	
	@When("I fill the CPF input with value $cpfValue")
	public void userFillInputCPF(@Named("cpfValue")String cpfValue){
		page.getForm().setCpfInputValue(cpfValue);
	}
	
	@When("I click on Register Account button")
	public void userClickRegisterAccountButton(){
		page.getForm().getRegisterAccountButton().click();
	}
	
	@Then("the Create Account Page should be loaded")
	public void validatePageLoaded(){
		Assert.assertTrue(page.isLoaded());
	}
	
	@Then("the return message should be $message")
	public void validateReturnMessage(@Named("message")String message){
		String messageFieldValue = page.getForm().getMessageField().getText();
		Assert.assertEquals(message, messageFieldValue);
	}
}
