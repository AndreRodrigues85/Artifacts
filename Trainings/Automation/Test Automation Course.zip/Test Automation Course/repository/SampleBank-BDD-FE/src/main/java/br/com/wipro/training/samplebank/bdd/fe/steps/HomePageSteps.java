package br.com.wipro.training.samplebank.bdd.fe.steps;

import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.wipro.training.samplebank.bdd.fe.lookup.SBElement;
import br.com.wipro.training.samplebank.bdd.fe.pages.HomePage;

@Component
public class HomePageSteps {
		
	@Autowired
	private HomePage homePage;
	
	@When("I click on Add Account Link")
	public void userClickAddAccountLink(){
		homePage.getAdminMenu().getAddAccountLink().click();
	}
	
	@Then("the home page should be successfull loaded")
	public void thenTheHomePageShouldBeSuccessfullLoaded() {
		Assert.assertTrue(homePage.isLoaded());
	}
	
	@Then("the user $username should be successful logged in")
	public void thenTheUserShouldBeSuccessfulLoggedin(@Named("username") String username) {
		
		SBElement usernameInfo = homePage.getUsernameTextField();
		String actualUsername = homePage.getUsernameValue();
		
		Assert.assertNotNull("Expected the user successful logged in, but it was not.", usernameInfo);
		Assert.assertEquals("Incorrect logged in username in welcome message. Expected: " + username
				+ ", but got: " + actualUsername, username, actualUsername);
	}
}