package br.com.wipro.training.samplebank.bdd.fe.steps;


import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.wipro.training.samplebank.bdd.fe.pages.MainPage;

@Component
public class MainPageSteps {
	
	@Autowired
	private MainPage mainPage;

	@Given("the user access the Sample Bank index page")
	public void givenUserAccessTheMainPage() {
		mainPage.goToMainPage();
	}
	
	@When("the user fill the login fields with the username $username and the password $password")
	public void whenUserFillsLoginFields(@Named("username") String username,
			@Named("password") String password) {
		mainPage.getLoginForm().fillUsernameInput(username);
		mainPage.getLoginForm().fillPasswordInput(password);
	}
	
	@When("the user click in the Login button")
	public void whenUserClickLoginButton() {
		mainPage.getLoginForm().clickOnLoginButton();
	}
	
	
}