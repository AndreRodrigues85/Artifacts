package br.com.wipro.training.samplebank.bdd.fe.util;

import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.AfterScenario.Outcome;
import org.jbehave.core.failures.UUIDExceptionWrapper;
import org.jbehave.web.selenium.WebDriverProvider;
import org.jbehave.web.selenium.WebDriverScreenshotOnFailure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class CustomWebDriverScreenshot extends WebDriverScreenshotOnFailure {

	@Autowired
	public CustomWebDriverScreenshot(@Qualifier("webDriverProvider")WebDriverProvider driverProvider) {
		super(driverProvider);
		// TODO Auto-generated constructor stub
	}
	
	@AfterScenario(uponOutcome = Outcome.SUCCESS)
	@Override
	public void afterScenarioFailure(UUIDExceptionWrapper arg0)
			throws Exception {
		// TODO Auto-generated method stub
		super.afterScenarioFailure(arg0);
	}

}
