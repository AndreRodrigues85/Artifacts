package br.com.wipro.training.samplebank.bdd.fe.util;

import org.jbehave.web.selenium.WebDriverProvider;
import org.openqa.selenium.JavascriptExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JavaScriptExecutorHelper {

	@Autowired
	private WebDriverProvider webDriverProvider;
	
	public void executeJavaScript(String script) {
		((JavascriptExecutor)webDriverProvider.get()).executeScript(script);
	}
}
