package br.com.wipro.training.samplebank.bdd.fe.util;

import org.jbehave.web.selenium.WebDriverProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class NavigatorHelper {

	@Autowired
	private WebDriverProvider driverProvider;
	
	public void navigateTo(String url){
		driverProvider.get().navigate().to(url);
	}
}
