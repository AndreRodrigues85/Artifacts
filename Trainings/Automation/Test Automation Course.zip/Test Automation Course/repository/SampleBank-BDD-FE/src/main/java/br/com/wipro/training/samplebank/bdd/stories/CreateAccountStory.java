package br.com.wipro.training.samplebank.bdd.stories;

import br.com.wipro.training.samplebank.bdd.fe.AbstractStory;

public class CreateAccountStory extends AbstractStory {

}
