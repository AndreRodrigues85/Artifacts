package br.com.wipro.training.samplebank.bdd.lifecycle;

import java.util.List;

import org.jbehave.core.annotations.AfterScenario;
import org.jbehave.core.annotations.AfterScenario.Outcome;
import org.jbehave.core.annotations.ScenarioType;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.wipro.training.samplebank.bdd.context.TestExecutionContext;
import br.com.wipro.training.samplebank.bdd.service.AccountTestService;
import br.com.wipro.training.samplebank.dto.account.Account;

public class ScenarioLifecycle {

	@Autowired
	private TestExecutionContext context;

	@Autowired
	private AccountTestService accountService;

	@AfterScenario(uponType = ScenarioType.ANY, uponOutcome = Outcome.ANY)
	public void tearDownScenario() {
		
		List<Account> accounts = context.getCreatedAccounts();
		
		for (Account account : accounts) {
			if (account != null) {
				accountService.deleteAccount(account.getOwnerCpf());
			}
		}
		
		context.getCreatedAccounts().clear();
	}
}