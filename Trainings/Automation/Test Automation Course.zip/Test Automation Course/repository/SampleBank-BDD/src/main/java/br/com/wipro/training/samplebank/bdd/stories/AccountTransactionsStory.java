package br.com.wipro.training.samplebank.bdd.stories;

import br.com.wipro.training.samplebank.bdd.AbstractStory;

public class AccountTransactionsStory extends AbstractStory {

}