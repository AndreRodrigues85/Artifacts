package br.com.wipro.training.samplebank.web.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import br.com.wipro.training.samplebank.domain.Account;
import br.com.wipro.training.samplebank.web.controller.api.AccountController;
import br.com.wipro.training.samplebank.web.response.ResponseDTO;

@Controller
public class AdminController {
	
	@Autowired
	private AccountController accountController;
	
	@RequestMapping(value = {"/addAccount"}, method = RequestMethod.GET)
	public String rootAddAccount(Model model) {
		model.addAttribute("account",  new Account(""));
		return "addAccount";
	}
	
	@RequestMapping(value = {"/addAccount"}, method = RequestMethod.POST)
	public String saveAccount(Account account, HttpServletResponse httpResponse, Model model) {

		ResponseDTO<Account> responseDTO = accountController.createAccount(account.getOwnerCpf(), httpResponse);
		model.addAttribute("responseDTO", responseDTO);
				
		return rootAddAccount(model);
	}
	
}
