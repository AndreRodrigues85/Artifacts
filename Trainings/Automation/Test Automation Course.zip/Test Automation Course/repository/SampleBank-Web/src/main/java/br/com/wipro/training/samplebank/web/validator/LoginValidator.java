package br.com.wipro.training.samplebank.web.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import br.com.wipro.training.samplebank.web.domain.Login;

@Component("loginValidator")
public class LoginValidator implements Validator {
	
	@Override
	public boolean supports(Class<?> clazz) {
		return Login.class.equals(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "username.required", "jdhasjdasd");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "password.required", "asdasdasda");
		
		
	}
}