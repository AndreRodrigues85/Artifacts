package br.com.wipro.training.bdd.stories;

import br.com.wipro.training.bdd.AbstractStory;

public class FirstStoryExample extends AbstractStory {

}
